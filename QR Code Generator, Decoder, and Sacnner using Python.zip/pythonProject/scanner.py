# Zeynep Sener
# 29-04-2024
# QR Code Scanner through the webcam


import webbrowser  
from PIL import Image 
import requests  
from io import BytesIO  

# initialize the video capture from the default webcam
cap = cv2.VideoCapture(0)

# initialize the cv2 QR code detector
detector = cv2.QRCodeDetector()

def display_image_from_url(url):
    # displays an image or GIF from a URL using PIL.
    try:
        response = requests.get(url)  # sends a GET request to the URL to fetch the image.
        image = Image.open(BytesIO(response.content))  # opens the image from the response's content, converting it to an image object.
        image.show()  
    except Exception as e:  # catches any errors that may occur during the process.
        print(f"Failed to load image from URL {url}: {e}")  

def handle_data(data):
    # processes the decoded data from a QR code.
    print("[+] QR Code detected, data:", data)  
    if data.startswith("http://") or data.startswith("https://"):  # checks if the data is a URL.
        # check if the URL ends with a typical image file extension.
        if any(data.lower().endswith(ext) for ext in [".jpg", ".jpeg", ".png", ".gif"]):
            print("Image or GIF URL detected. Displaying image.")  
            display_image_from_url(data)  # calls the function to display the image.
        else:
            print("URL detected. Opening in browser...")  
            webbrowser.open(data) 
    elif data.startswith("geo:"):
        print("Geolocation detected:", data)  
    else:
        print("Data:", data)  # handles any other data type by just printing it.

# main loop to continuously capture frames from the webcam.
while True:
    ret, img = cap.read()  # reads a frame from the video capture object.
    if not ret:
        print("Failed to grab frame")  # prints an error message if no frame is captured.
        break  # exits the loop if frame capture fails.

    data, bbox, _ = detector.detectAndDecode(img)  # detects and decodes QR codes from the frame.
    if data:
        handle_data(data)  # processes the data if a QR code is detected.

    cv2.imshow("QR Code Scanner", img)  # displays the image in a window titled "QR Code Scanner".
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break  # exits the loop if 'q' is pressed.

cap.release()  
cv2.destroyAllWindows()  

