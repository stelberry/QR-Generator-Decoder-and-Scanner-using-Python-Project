#Creating Some of the one-dimensional barcode

import barcode
from barcode.writer import ImageWriter

#choose the barcode type you want to create (e.g., 'ean13', 'ean8', 'code39', 'code128')

#code128 type barcode
barcode_type = 'code128'
# The data you want to encode in the barcode, since I chose code128, it supports any character of the ASCII 128 character set
barcode_data = '036^067GG'
# Create the barcode
barcode_class = barcode.get_barcode_class(barcode_type)
my_barcode = barcode_class(barcode_data, writer=ImageWriter())
my_barcode.save('barcode') # Save the barcode to a file


#EAN8 type barcode
#7 digits, the 8th digit is a checksum
from barcode import EAN8
data = '1133885'
my_barcode = EAN8(data)
my_barcode.save('EAN8 barcode')


#EAN13 type barcode
#12 digits, the 13th digit is a checksum
from barcode import EAN13
data = '123456789101'
my_barcode = EAN13(data)
my_barcode.save('EAN13 barcode')


#CODE39 type barcode
#can include uppercase letters, digits, and a few special characters
barcode_data = 'HELLO123$'
# Create Code39 barcode
code39 = barcode.get('code39', barcode_data, writer=ImageWriter())
code39.save('code39 barcode')


#color barcode
barcode_data = 'BEE148*'
# Create the barcode
barcode_class = barcode.get_barcode_class('code128')
my_barcode = barcode_class(barcode_data, writer=ImageWriter())
my_barcode.save('color barcode', options = {"foreground": "purple", #color
                                          "module_width": 0.5, #width
                                          "modele_height": 40 #height
                                         })
