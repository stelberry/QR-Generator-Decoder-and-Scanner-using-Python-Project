# -*- coding: utf-8 -*-
"""
Created on Sun Apr 28 20:16:22 2024

@author: USER
"""

import qrcode
from PIL import Image, ImageDraw
from qrcode.image.styledpil import StyledPilImage
from qrcode.image.styles.moduledrawers import (
    CircleModuleDrawer, SquareModuleDrawer
)
import matplotlib.pyplot as plt
#%matplotlib inline

def show_qr(img):
    plt.figure(figsize=(5,5))
    plt.imshow(img)
    plt.axis('off')
    plt.show()
    
qr = qrcode.QRCode(
    #control complexity
    version=10,  
    error_correction=qrcode.constants.ERROR_CORRECT_H,
    box_size=10,
    border=18,
    mask_pattern=4, 
)
qr.add_data('https://youtube.com/')
qr.make(fit=True)

img = qr.make_image(
    fill_color="white",
    back_color=None,
    image_factory=StyledPilImage,
    module_drawer=CircleModuleDrawer(resample_method=None),
    eye_drawer=SquareModuleDrawer(),
)
#for version 10 only below

# get fill texture
width, height = img.size
left = 0
top = height // 3
right = width
bottom = 2 * height//3

img_copy = img.copy()
draw_rec = ImageDraw.Draw(img_copy)
draw_rec.rectangle(
    (left, top, right, bottom),
    fill = None,
    outline ='red',
    width=5
)

cropped_section = img.crop((left, top, right, bottom))
#show_qr(cropped_section)

rotated_crop = cropped_section.copy()
rotated_crop = rotated_crop.rotate(90, expand=True)

# fill top
img.paste(cropped_section, (0, -cropped_section.size[1]//2 + 20 ))
# fill bottom
img.paste(cropped_section, (0, img.size[1] - cropped_section.size[1]//2 -20 ))
# fill left
img.paste(rotated_crop, (-rotated_crop.size[0]//2 + 20, 0))
# fill right
img.paste(rotated_crop, (img.size[0] - rotated_crop.size[0]//2 - 20, 0))



img_copy = img.copy()
draw = ImageDraw.Draw(img_copy)
draw.ellipse(
    (30, 30, img_copy.size[1]-30, img_copy.size[1]-30),
    fill = None,
    outline ='black',
    width=30
)

# draw outside mask ring
draw.ellipse(
    (-rotated_crop.size[0],
     -cropped_section.size[1],
     img.size[1] + rotated_crop.size[0],
     img.size[1] + cropped_section.size[1]
     ),
    fill = None,
    outline ='white',
    width=340
)
#show qrcode a plot
show_qr(img_copy)

