#QR and 1D Barcode Generator

import qrcode
import barcode
from barcode.writer import ImageWriter

def generate_qr_code(data):
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=2,
    )
    qr.add_data(data)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    filename = "qr_code.png"
    img.save(filename)
    print("QR code saved as: ", filename)

def generate_barcode(data):
    barcode_class = barcode.get_barcode_class('code128')
    my_barcode = barcode_class(data, writer=ImageWriter())
    filename = "barcode.png"
    my_barcode.save(filename)
    print("Barcode saved as: ", filename)

def main():
    while True:
        choice = input("Do you want to generate a QR code or a barcode? Enter 'qr' or 'bar':\n")
        if choice == 'qr':
            data = input("Enter the data to encode: ")
            generate_qr_code(data)

        elif choice == 'bar':
            data = input("Enter the data to encode: ")
            generate_barcode(data)
        else:
            print("Invalid")
            continue
        break

main()
