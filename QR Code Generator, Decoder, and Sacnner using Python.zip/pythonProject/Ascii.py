# import necessary libraries
from PIL import Image  # PIL library for image processing
import numpy as np  # NumPy for array manipulation
import os  # OS module for file handling


# function to read QR code image and convert it to a binary matrix
def read_qr_code_image(image_path):
    # open the image and convert it to grayscale
    image = Image.open(image_path).convert('L')
    # convert the image to a binary matrix
    qr_matrix = np.array(image) < 128
    return qr_matrix


# function to convert binary matrix representation of QR code to ASCII art
def qr_image_to_ascii(qr_matrix):
    ascii_art = ""
    for row in qr_matrix:
        for col in row:
            if col:
                ascii_art += "██"  # Use full block for black modules
            else:
                ascii_art += "  "  # Use spaces for white modules
        ascii_art += "\n"
    return ascii_art


# function to save ASCII art to a file
def save_ascii_art(ascii_art, output_path):
    # If the output path is a directory, append file name to it
    if os.path.isdir(output_path):
        output_path = os.path.join(output_path, 'ascii_art.txt')
    # Write ASCII art to the output file
    with open(output_path, 'w') as file:
        file.write(ascii_art)


# main function to run the script
if __name__ == "__main__":
    # input image and output path from user
    image_path = input("Enter the path to the QR code image: ")
    output_path = input("Enter the path to save the ASCII art: ")

    # read QR code image and convert it to binary matrix
    qr_matrix = read_qr_code_image(image_path)
    # convert binary matrix to ASCII art
    ascii_art = qr_image_to_ascii(qr_matrix)

    # display ASCII art of the QR code
    print("\nHere is your QR code in ASCII art:\n")
    print(ascii_art)

    # save ASCII art to a file
    save_ascii_art(ascii_art, output_path)
    print(f"\nASCII art saved to {output_path}")
