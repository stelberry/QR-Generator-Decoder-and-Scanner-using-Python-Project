import qrcode
import segno
import numpy as np
import cv2

#basic
data = 'this is python group project'
img = qrcode.make(data)
img.save('qrcode1.png')
############

#basic (jpg)
data = 'this is python group project'
img = qrcode.make(data)
img.save('qrcode1.jpg', 'JPEG')
############

#modified QRCode(size and color)
qr = qrcode.QRCode(version = 1, #highest fault tolerance rate
                   error_correction=qrcode.constants.ERROR_CORRECT_L,
                   box_size = 50, #the whole size
                   border=10)
qr.add_data("https://www.netflix.com/browse")
qr.make(fit=True)
img1 = qr.make_image(fill_color="orange", back_color = "lightblue") #change color
img1.save('modified qrcode.png')

print("size of the QR image:")
print(np.array(qr.get_matrix()).shape)
#############

#expandable resolution(SVG)
import qrcode.image.svg as qis
factory = qis.SvgPathImage
svg_img = qrcode.make("this is svg image", image_factory =factory)
svg_img.save("svg qrcode.svg")
#################


#basic qr code using segno
img2 = segno.make_qr("hi, I am stella!")
img2.save("segno basic qrcode.png")
##################

#changing color using segno
# lightblue_qrcode.py
img3 = segno.make_qr("https://www.youtube.com/")
img3.save(
        "segno color qrcode.png",
        dark="ffccbf", #qrcode color
)
##################

#changing border, size, color with segno
img4 = segno.make_qr("I am learning python!")
img4.save(
    "modified segno qrcode.png",
        scale=10, #size
        border=5,
        light = "darkblue", #qrcode color
        dark = "#ffccbf", #background color
        quiet_zone = "#c5ffd1", #border color
)
##################

#2 color qrcode using segno
img5 = segno.make_qr("https://www.youtube.com/")
img5.save(
        "2 color qrcode.png",
        scale = 5,
        border = 5,
        light="lightpink",
        dark="darkblue",
        data_dark="green",
)
##################

#3 color qrcode using segno
img6 = segno.make_qr("https://youtu.be/dQw4w9WgXcQ?si=z9WsX13FoCEgTQ-c")
img6.save("3 color qrcode.png",
          scale = 8,
          border = 3,
          light = "#405544",
          dark = "#bfffcc",
          quiet_zone = "#7faa88",
          data_dark = "#aa7f8d",
          data_light = "#f4ffbf")
##################


#finder color
img7 = segno.make_qr("https://www.youtube.com/")
img7.save("finder color qrcode.png",
          scale = 7,
          border = 4,
          dark = "red",
          data_dark = "black",
          )
##################


#rotated qr code
qrcode = segno.make_qr("This is python group project")
rotate_qr = qrcode.to_pil(
    scale=5,
    light="lightblue",
    dark="405544",
).rotate(45, expand=True)
rotate_qr.save("formatted_rotated_qrcode.png")
##################


#Animated QR code
from MyQR import myqr
version, level, qr_name = myqr.run(words= "https://youtu.be/dQw4w9WgXcQ?si=z9WsX13FoCEgTQ-c",
                                   version = 1,
                                   level = 'H', #error correction level(L,M,Q,H)
                                   picture = "cat.gif",
                                   colorized = True,
                                   )
##################


#Image QR code
version, level, qr_name = myqr.run(words= "https://www.youtube.com/",
                                   version = 1,
                                   level = 'L', #error correction level(L,M,Q,H)
                                   picture = "royalholloway.jpg",
                                   colorized = True,
                                   )
##################


#Decode QR code using Qr code image

filename = "2 color qrcode.png"#name of the qrcode file
image = cv2.imread(filename)  #read the qrcode image
detector = cv2.QRCodeDetector()  #initialize QRCode detector
data, vertices_array, _ = detector.detectAndDecode(image)#detect and decode
if vertices_array is not None:
    print("QR code detected: ", data)
else:
    print("Error")


#############################################






